#include <stdio.h>

int main()
{
    int a, b, c, d;

    printf("Enter IP address: ");
    scanf("%d.%d.%d.%d", &a, &b, &c, &d);

    if(a >= 1 && a <= 126)
    {
        printf("Class A\n");
        printf("Subnet Mask: 255.0.0.0\n");
        printf("Network Address: %d.0.0.0", a);
    }
    else if(a >= 128 && a <= 191)
    {
        printf("Class B\n");
        printf("Subnet Mask: 255.255.0.0\n");
        printf("Network Address: %d.%d.0.0", a, b);
    }
    else if(a >= 192 && a <= 223)
    {
        printf("Class C\n");
        printf("Subnet Mask: 255.255.255.0\n");
        printf("Network Address: %d.%d.%d.0", a, b, c);
    }
    else if(a >= 224 && a <= 239)
    {
        printf("Class D");
    }
    else if(a >= 240 && a <= 255)
    {
        printf("Class E");
    }
    else
    {
        printf("Special or Invalid IP Address");
    }

    return 0;
}

/*
Enter IP address: 192.168.1.10
Class C
Subnet Mask: 255.255.255.0
Network Address: 192.168.1.0
*/