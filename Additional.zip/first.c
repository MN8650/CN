#include <stdio.h>

int main()
{
    int w, i, f, frames[50], ack;

    printf("Enter window size: ");
    scanf("%d", &w);

    printf("\nEnter number of frames to transmit: ");
    scanf("%d", &f);

    if (w <= 0 || f <= 0 || f >= 50)
        return 1;

    printf("\nEnter %d frames: ", f);

    for (i = 1; i <= f; i++)
        scanf("%d", &frames[i]);

    for (i = 1; i <= f; i++)
    {
        printf("\nFrame %d sent\n", frames[i]);

        printf("Received? (1=Yes, 0=No): ");
        scanf("%d", &ack);

        if (ack == 1)
            printf("Acknowledgement received\n");
        else
        {
            printf("Frame %d lost\n", frames[i]);
            printf("Retransmitting frame %d\n", frames[i]);
            printf("Acknowledgement received\n");
        }

        if (i % w == 0 || i == f)
            printf("-----\n");
    }

    return 0;
}


/*
Enter window size: 3

Enter number of frames to transmit: 5

Enter 5 frames: 10 20 30 40 50

Frame 10 sent
Received? (1=Yes, 0=No): 1
Acknowledgement received

Frame 20 sent
Received? (1=Yes, 0=No): 0
Frame 20 lost
Retransmitting frame 20
Acknowledgement received

Frame 30 sent
Received? (1=Yes, 0=No): 1
Acknowledgement received
-----

Frame 40 sent
Received? (1=Yes, 0=No): 1
Acknowledgement received

Frame 50 sent
Received? (1=Yes, 0=No): 1
Acknowledgement received
-----
*/