#include <stdio.h>

int main()
{
    int a[8], i, p1, p2, p4, error;

    printf("Enter 4 data bits: ");
    scanf("%d%d%d%d", &a[3], &a[5], &a[6], &a[7]);

    a[1] = a[3] ^ a[5] ^ a[7];
    a[2] = a[3] ^ a[6] ^ a[7];
    a[4] = a[5] ^ a[6] ^ a[7];

    printf("Hamming Code: ");
    for(i = 1; i <= 7; i++)
        printf("%d", a[i]);

    printf("\nEnter received code: ");
    for(i = 1; i <= 7; i++)
        scanf("%1d", &a[i]);

    p1 = a[1] ^ a[3] ^ a[5] ^ a[7];
    p2 = a[2] ^ a[3] ^ a[6] ^ a[7];
    p4 = a[4] ^ a[5] ^ a[6] ^ a[7];

    error = p1 + 2*p2 + 4*p4;

    if(error == 0)
        printf("No Error");
    else
    {
        printf("Error at position %d\n", error);
        a[error] = 1 - a[error];

        printf("Corrected Code: ");
        for(i = 1; i <= 7; i++)
            printf("%d", a[i]);
    }

    return 0;
}

/*
Enter 4 data bits: 1 0 1 1
Hamming Code: 0110011
Enter received code: 0110111
Error at position 5
Corrected Code: 0110011
*/