#include <stdio.h>

int main()
{
    int bucket, rate, n, packet, tokens = 0, i;

    printf("Enter bucket size: ");
    scanf("%d", &bucket);

    printf("Enter token generation rate: ");
    scanf("%d", &rate);

    printf("Enter number of packets: ");
    scanf("%d", &n);

    for(i = 1; i <= n; i++)
    {
        tokens += rate;

        if(tokens > bucket)
            tokens = bucket;

        printf("\nEnter packet size: ");
        scanf("%d", &packet);

        if(packet <= tokens)
        {
            tokens -= packet;
            printf("Packet sent successfully\n");
        }
        else
        {
            printf("Packet dropped\n");
        }

        printf("Remaining tokens: %d\n", tokens);
    }

    return 0;
}

/*

Enter bucket size: 10
Enter token generation rate: 5
Enter number of packets: 4

Enter packet size: 3
Packet sent successfully
Remaining tokens: 2

Enter packet size: 6
Packet sent successfully
Remaining tokens: 1

Enter packet size: 8
Packet dropped
Remaining tokens: 6

Enter packet size: 4
Packet sent successfully
Remaining tokens: 6

*/