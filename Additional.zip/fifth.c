#include <stdio.h>
#include <string.h>
#include <math.h>

int main()
{
    int p = 17, q = 11;
    int n = p * q;
    int phi = (p - 1) * (q - 1);
    int e = 7, d = 23;

    char msg[100], decrypted[100];
    int encrypted[100], i;

    printf("Enter message: ");
    scanf("%99s", msg);

    for(i = 0; msg[i] != '\0'; i++)
        encrypted[i] = (int)pow(msg[i], e) % n;

    printf("Encrypted Message: ");
    for(i = 0; msg[i] != '\0'; i++)
        printf("%d ", encrypted[i]);

    for(i = 0; msg[i] != '\0'; i++)
        decrypted[i] = (int)pow(encrypted[i], d) % n;

    decrypted[i] = '\0';

    printf("\nDecrypted Message: %s\n", decrypted);

    return 0;
}

Enter message: HELLO
Encrypted Message: 30 69 76 76 134
Decrypted Message: HELLO